[
    {
        "request_id": "REQ-001",
        "employee_id": "EMP-001",
        "type": "laptop",
        "status": "approved",
        "approved_by": "EMP-004",
    },
    {
        "request_id": "REQ-002",
        "employee_id": "EMP-002",
        "type": "expense",
        "status": "pending",
        "approved_by": "None",
    },
    {
        "request_id": "REQ-003",
        "employee_id": "EMP-003",
        "type": "travel",
        "status": "rejected",
        "approved_by": "EMP-002",
    },
    {
        "request_id": "REQ-004",
        "employee_id": "EMP-004",
        "type": "mobile",
        "status": "approved",
        "approved_by": "EMP-003",
    },
    {
        "request_id": "REQ-005",
        "employee_id": "EMP-005",
        "type": "travel",
        "status": "pending",
        "approved_by": "None",
    },
]
