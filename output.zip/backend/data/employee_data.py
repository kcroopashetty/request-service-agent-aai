employees = [
    {
        "employee_id": "EMP-001",
        "name": "Aarav Sharma",
        "email": "aarav.sharma@company.com",
        "department": "Engineering",
    },
    {
        "employee_id": "EMP-002",
        "name": "Priya Nair",
        "email": "priya.nair@company.com",
        "department": "Finance",
    },
    {
        "employee_id": "EMP-003",
        "name": "Rohan Mehta",
        "email": "rohan.mehta@company.com",
        "department": "Human Resources",
    },
    {
        "employee_id": "EMP-004",
        "name": "Isha Verma",
        "email": "isha.verma@company.com",
        "department": "IT Support",
    },
    {
        "employee_id": "EMP-005",
        "name": "Vikram Singh",
        "email": "vikram.singh@company.com",
        "department": "Sales",
    },
]
